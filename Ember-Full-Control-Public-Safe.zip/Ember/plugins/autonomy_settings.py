"""Settings surface for desktop/game/messaging autonomy."""
from __future__ import annotations

from core import autonomy

PLUGIN = {
    "name": "autonomy_settings",
    "description": "Reads or changes Ember autonomy settings for desktop control, game control, messaging, and WhatsApp background auto-replies.",
    "permissions": ["privacy.read"],
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "status | set"},
            "setting": {"type": "STRING", "description": "Setting key"},
            "value": {"type": "STRING", "description": "New value"}
        },
        "required": ["action"]
    }
}

PLUGIN_SETTINGS = {
    "namespace": "autonomy",
    "title": "Ember Autonomy & Messaging",
    "fields": [
        {"key": "desktop_control_enabled", "label": "Desktop control", "type": "toggle", "default": True},
        {"key": "game_control_enabled", "label": "Game control", "type": "toggle", "default": True},
        {"key": "messaging_enabled", "label": "Messaging actions", "type": "toggle", "default": True},
        {"key": "whatsapp_auto_reply", "label": "WhatsApp automatic replies", "type": "toggle", "default": False},
        {"key": "whatsapp_auto_reply_all", "label": "Auto-reply to all unread chats", "type": "toggle", "default": False},
        {"key": "whatsapp_auto_reply_contacts", "label": "Allowed contacts (comma separated)", "type": "text", "placeholder": "Friend One, Family Group"},
        {"key": "whatsapp_high_stakes_guard", "label": "Pause auto-reply for high-stakes messages", "type": "toggle", "default": True},
        {"key": "whatsapp_poll_seconds", "label": "WhatsApp check interval (seconds)", "type": "text", "default": "6"},
    ]
}


def _coerce(key: str, value):
    if key in {
        "desktop_control_enabled", "game_control_enabled", "messaging_enabled",
        "whatsapp_auto_reply", "whatsapp_auto_reply_all", "whatsapp_high_stakes_guard",
    }:
        if isinstance(value, bool): return value
        return str(value).strip().lower() in {"1", "true", "on", "yes", "enable", "enabled"}
    if key == "whatsapp_auto_reply_contacts":
        return [x.strip() for x in str(value or "").split(",") if x.strip()]
    if key == "whatsapp_poll_seconds":
        try: return int(value)
        except Exception: return 6
    return value


def run(parameters: dict, player=None, session_memory=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "status").lower().strip()
    if action == "status":
        return autonomy.status_text()
    if action == "set":
        key = str(p.get("setting") or "").strip()
        if key not in autonomy.DEFAULTS:
            return f"Unknown autonomy setting: {key}."
        val = _coerce(key, p.get("value"))
        autonomy.save({key: val})
        if key == "whatsapp_auto_reply" and bool(val):
            try:
                from core import whatsapp_web
                whatsapp_web.start_if_enabled()
            except Exception:
                pass
        return f"{key} = {autonomy.load().get(key)}"
    return "Use action=status or action=set."
