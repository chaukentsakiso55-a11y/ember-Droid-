"""Low-latency game keyboard control for Ember.

Uses PyDirectInput on Windows when available because many DirectX games ignore
ordinary GUI automation key events. PyAutoGUI remains the cross-platform
fallback. Keys are always released on exit/failure to avoid a stuck throttle.
"""
from __future__ import annotations

import atexit
import json
import platform
import subprocess
import threading
import time
from pathlib import Path

from core.autonomy import get as autonomy_get

try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.02
except Exception:
    pyautogui = None

try:
    if platform.system() == "Windows":
        import pydirectinput
        pydirectinput.PAUSE = 0.01
    else:
        pydirectinput = None
except Exception:
    pydirectinput = None

BASE_DIR = Path(__file__).resolve().parent.parent
PROFILES_PATH = BASE_DIR / "config" / "game_profiles.json"
_HELD: set[str] = set()
_LOCK = threading.RLock()

_DEFAULT_PROFILES = {
    "generic_racing": {
        "window": "",
        "accelerate": "up", "brake": "down", "left": "left", "right": "right",
        "powerup": "space", "ability": "a"
    },
    "beach_buggy_racing": {
        "window": "Beach Buggy Racing",
        "accelerate": "up", "brake": "down", "left": "left", "right": "right",
        "powerup": "space", "ability": "a"
    },
    "beach_buggy_racing_2": {
        "window": "Beach Buggy Racing 2",
        "accelerate": "up", "brake": "down", "left": "left", "right": "right",
        "powerup1": "s", "powerup2": "d", "ability": "a", "powerslide": "w", "boost_start": "enter"
    }
}


def _load_profiles() -> dict:
    try:
        data = json.loads(PROFILES_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            merged = dict(_DEFAULT_PROFILES)
            merged.update(data)
            return merged
    except Exception:
        pass
    return dict(_DEFAULT_PROFILES)


def _backend():
    if pydirectinput is not None:
        return pydirectinput, "PyDirectInput"
    if pyautogui is not None:
        return pyautogui, "PyAutoGUI"
    raise RuntimeError("No keyboard automation backend is available.")


def _focus(title: str) -> bool:
    if not title:
        return True
    if platform.system() == "Windows":
        safe = title.replace('"', "")
        ps = f'(New-Object -ComObject WScript.Shell).AppActivate("{safe}")'
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            capture_output=True, text=True, timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        time.sleep(0.25)
        return result.returncode == 0
    return True


def _key_down(key: str) -> None:
    backend, _ = _backend()
    key = str(key).lower().strip()
    if not key:
        return
    backend.keyDown(key)
    with _LOCK:
        _HELD.add(key)


def _key_up(key: str) -> None:
    backend, _ = _backend()
    key = str(key).lower().strip()
    if not key:
        return
    try:
        backend.keyUp(key)
    finally:
        with _LOCK:
            _HELD.discard(key)


def _release_all() -> None:
    with _LOCK:
        keys = list(_HELD)
    for key in keys:
        try:
            _key_up(key)
        except Exception:
            pass


atexit.register(_release_all)


def _tap(key: str, presses: int = 1, interval: float = 0.05) -> None:
    backend, _ = _backend()
    backend.press(str(key).lower().strip(), presses=max(1, min(20, int(presses))), interval=max(0.0, min(1.0, float(interval))))


def _hold(keys: list[str], seconds: float) -> None:
    secs = max(0.02, min(30.0, float(seconds)))
    pressed: list[str] = []
    try:
        for key in keys:
            key = str(key).lower().strip()
            if key:
                _key_down(key); pressed.append(key)
        time.sleep(secs)
    finally:
        for key in reversed(pressed):
            _key_up(key)


def _profile(name: str) -> tuple[str, dict]:
    profiles = _load_profiles()
    key = str(name or "generic_racing").lower().strip().replace(" ", "_")
    aliases = {
        "bbr": "beach_buggy_racing",
        "beach_buggy": "beach_buggy_racing",
        "bbr2": "beach_buggy_racing_2",
        "beach_buggy_2": "beach_buggy_racing_2",
    }
    key = aliases.get(key, key)
    return key, dict(profiles.get(key) or profiles["generic_racing"])


def game_control(parameters: dict, response=None, player=None, session_memory=None) -> str:
    if not autonomy_get("game_control_enabled", True):
        return "Game control is disabled in Ember autonomy settings."
    p = parameters or {}
    action = str(p.get("action") or "status").lower().strip()
    prof_name, prof = _profile(p.get("profile", "generic_racing"))
    window = str(p.get("window") or prof.get("window") or "").strip()

    try:
        backend, backend_name = _backend()
        if action == "status":
            return f"Game control ready via {backend_name}. Profile: {prof_name}. Held keys: {', '.join(sorted(_HELD)) or 'none'}."
        if action == "focus":
            return f"Focused {window}." if _focus(window) else f"Could not focus {window}."
        if action == "release_all":
            _release_all(); return "Released all game-control keys."
        if window:
            _focus(window)

        if action == "tap":
            key = p.get("key") or p.get("control") or "space"
            key = prof.get(str(key).lower().strip(), key)
            _tap(key, p.get("presses", 1), p.get("interval", 0.05))
            return f"Pressed {key}."

        if action == "hold":
            raw = p.get("keys") or p.get("key") or "up"
            keys = raw if isinstance(raw, list) else [x.strip() for x in str(raw).replace("+", ",").split(",") if x.strip()]
            keys = [prof.get(str(k).lower(), k) for k in keys]
            secs = float(p.get("seconds", 0.5))
            _hold(keys, secs)
            return f"Held {'+'.join(map(str, keys))} for {max(0.02, min(30.0, secs)):.2f}s."

        if action in {"drive", "race_burst"}:
            steer = str(p.get("steer") or "straight").lower().strip()
            seconds = float(p.get("seconds", 0.45))
            keys = []
            if bool(p.get("accelerate", True)):
                keys.append(prof.get("accelerate", "up"))
            if bool(p.get("brake", False)):
                keys.append(prof.get("brake", "down"))
            if steer in {"left", "right"}:
                keys.append(prof.get(steer, steer))
            _hold(keys, seconds)
            if bool(p.get("powerup", False)):
                _tap(prof.get("powerup", prof.get("powerup1", "space")))
            if bool(p.get("ability", False)):
                _tap(prof.get("ability", "a"))
            return f"Race burst: steer={steer}, {seconds:.2f}s, keys={'+'.join(keys) or 'none'}."

        if action == "control":
            control = str(p.get("control") or "").lower().strip()
            if not control:
                return "Specify a game control name."
            key = prof.get(control)
            if not key:
                return f"'{control}' is not mapped in profile {prof_name}."
            seconds = float(p.get("seconds", 0.0) or 0.0)
            if seconds > 0:
                _hold([key], seconds)
            else:
                _tap(key)
            return f"Used {control} ({key})."

        if action == "sequence":
            # Compact macro syntax: up:1.5,left+up:0.35,space:0.05
            raw = str(p.get("sequence") or "").strip()
            if not raw:
                return "Provide a sequence such as up:1,left+up:0.3,space:0.05."
            steps = [x.strip() for x in raw.split(",") if x.strip()][:30]
            for step in steps:
                if ":" in step:
                    keys_raw, sec_raw = step.rsplit(":", 1)
                    try: secs = float(sec_raw)
                    except Exception: secs = 0.08
                else:
                    keys_raw, secs = step, 0.08
                keys = [prof.get(k.strip().lower(), k.strip().lower()) for k in keys_raw.split("+") if k.strip()]
                _hold(keys, max(0.02, min(5.0, secs)))
            return f"Completed {len(steps)} game-control steps."

        return f"Unknown game action: {action}."
    except Exception as e:
        _release_all()
        return f"Game control failed: {e}"


TOOL = {
    "name": "game_control",
    "description": (
        "Low-latency keyboard control for PC games, including Beach Buggy Racing. "
        "Can focus a game, tap/hold keys, steer while accelerating, use mapped game controls, run short macros, and release stuck keys. "
        "Use this instead of ordinary computer_control for active gameplay."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "status | focus | tap | hold | drive | race_burst | control | sequence | release_all"},
            "profile": {"type": "STRING", "description": "generic_racing | beach_buggy_racing | beach_buggy_racing_2"},
            "window": {"type": "STRING", "description": "Optional game window title override"},
            "key": {"type": "STRING", "description": "Keyboard key or mapped control name"},
            "keys": {"type": "ARRAY", "items": {"type": "STRING"}, "description": "Keys to hold together"},
            "control": {"type": "STRING", "description": "Mapped control such as accelerate, brake, left, right, powerup1, ability, powerslide"},
            "seconds": {"type": "NUMBER", "description": "Hold duration"},
            "steer": {"type": "STRING", "description": "left | right | straight"},
            "accelerate": {"type": "BOOLEAN"},
            "brake": {"type": "BOOLEAN"},
            "powerup": {"type": "BOOLEAN"},
            "ability": {"type": "BOOLEAN"},
            "presses": {"type": "INTEGER"},
            "interval": {"type": "NUMBER"},
            "sequence": {"type": "STRING", "description": "Macro like up:1,left+up:0.3,space:0.05"}
        },
        "required": ["action"]
    },
    "handler": game_control,
}
