"""Natural-language WhatsApp control for Ember."""
from __future__ import annotations

from core import autonomy, whatsapp_web


def _contacts(value) -> list[str]:
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value or "").split(",") if x.strip()]


def whatsapp_control(parameters: dict, response=None, player=None, session_memory=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "status").lower().strip()

    if action in {"login", "open", "connect"}:
        r = whatsapp_web.open_login()
        if r.get("ok"):
            return "WhatsApp Web opened. It is signed in." if r.get("signed_in") else "WhatsApp Web opened. Scan its QR code once to connect Ember."
        return r.get("error", "Could not open WhatsApp Web.")

    if action in {"send", "message"}:
        contact = str(p.get("contact") or p.get("receiver") or "").strip()
        text = str(p.get("message") or p.get("text") or "").strip()
        r = whatsapp_web.send_message(contact, text)
        return f"Message sent to {contact} on WhatsApp." if r.get("ok") else r.get("error", "Message was not sent.")

    if action in {"read", "read_last", "check_contact"}:
        contact = str(p.get("contact") or p.get("receiver") or "").strip()
        if not contact:
            return "Specify the WhatsApp contact to read."
        r = whatsapp_web.read_last(contact)
        if not r.get("ok"):
            return r.get("error", "Could not read the WhatsApp chat.")
        msg = str(r.get("message") or "").strip()
        return f"Latest incoming message from {contact}: {msg}" if msg else f"No readable incoming text from {contact}."

    if action in {"check", "unread", "check_unread"}:
        r = whatsapp_web.unread_contacts()
        if not r.get("ok"):
            return r.get("error", "Could not check WhatsApp.")
        names = r.get("contacts") or []
        return "Unread WhatsApp chats: " + ", ".join(names) if names else "No unread WhatsApp chats were detected."

    if action in {"auto_reply_on", "enable_auto_reply"}:
        autonomy.save({"whatsapp_auto_reply": True})
        whatsapp_web.start_if_enabled()
        return "WhatsApp auto-reply is ON. It will only reply to allowlisted contacts unless auto-reply-all is also enabled."

    if action in {"auto_reply_off", "disable_auto_reply"}:
        autonomy.save({"whatsapp_auto_reply": False})
        return "WhatsApp auto-reply is OFF."

    if action in {"allow_contact", "add_contact"}:
        contact = str(p.get("contact") or "").strip()
        if not contact:
            return "Specify a contact to allow for auto-reply."
        cfg = autonomy.load(); contacts = list(cfg.get("whatsapp_auto_reply_contacts", []))
        if contact not in contacts: contacts.append(contact)
        autonomy.save({"whatsapp_auto_reply_contacts": contacts})
        return f"{contact} is allowed for WhatsApp auto-reply."

    if action in {"remove_contact", "disallow_contact"}:
        contact = str(p.get("contact") or "").strip()
        cfg = autonomy.load(); contacts = [x for x in cfg.get("whatsapp_auto_reply_contacts", []) if str(x).casefold() != contact.casefold()]
        autonomy.save({"whatsapp_auto_reply_contacts": contacts})
        return f"{contact} was removed from the WhatsApp auto-reply list."

    if action in {"auto_reply_all_on", "enable_auto_reply_all"}:
        autonomy.save({"whatsapp_auto_reply_all": True})
        return "Auto-reply-all is ON. Background reply safety and rate limits remain active."

    if action in {"auto_reply_all_off", "disable_auto_reply_all"}:
        autonomy.save({"whatsapp_auto_reply_all": False})
        return "Auto-reply-all is OFF."

    if action == "status":
        cfg = autonomy.load(); st = whatsapp_web.status()
        contacts = cfg.get("whatsapp_auto_reply_contacts", [])
        return (
            f"WhatsApp control: {'running' if st.get('running') else 'idle'}; "
            f"signed in: {'yes' if st.get('signed_in') else 'not confirmed'}; "
            f"auto-reply: {'ON' if cfg.get('whatsapp_auto_reply') else 'OFF'}; "
            f"auto-reply-all: {'ON' if cfg.get('whatsapp_auto_reply_all') else 'OFF'}; "
            f"allowlist: {', '.join(contacts) if contacts else 'none'}."
        )

    return f"Unknown WhatsApp action: {action}."


TOOL = {
    "name": "whatsapp_control",
    "description": (
        "Controls WhatsApp Web: open/login, send a message, read the latest incoming message, check unread chats, "
        "and manage Ember's optional background auto-reply mode. For direct WhatsApp requests use this tool instead of generic desktop clicking."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "login | send | read_last | check_unread | auto_reply_on | auto_reply_off | allow_contact | remove_contact | auto_reply_all_on | auto_reply_all_off | status"},
            "contact": {"type": "STRING", "description": "WhatsApp contact or chat name"},
            "receiver": {"type": "STRING"},
            "message": {"type": "STRING", "description": "Message text"},
            "text": {"type": "STRING"}
        },
        "required": ["action"]
    },
    "handler": whatsapp_control,
}
