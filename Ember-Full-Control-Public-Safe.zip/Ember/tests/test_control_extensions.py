import unittest
from unittest.mock import patch

from core import autonomy
from core import local_mode
from core.whatsapp_web import WhatsAppWorker
from actions import game_control as game


class ControlExtensionTests(unittest.TestCase):
    def test_autonomy_normalises_contacts_and_poll_interval(self):
        cfg = autonomy._normalise({
            "whatsapp_auto_reply_contacts": "Alex, Sam, Alex",
            "whatsapp_poll_seconds": "1",
        })
        self.assertEqual(cfg["whatsapp_auto_reply_contacts"], ["Alex", "Sam"])
        self.assertEqual(cfg["whatsapp_poll_seconds"], 3)

    def test_beach_buggy_2_profile_has_held_key_controls(self):
        name, profile = game._profile("bbr2")
        self.assertEqual(name, "beach_buggy_racing_2")
        self.assertEqual(profile["accelerate"], "up")
        self.assertEqual(profile["left"], "left")
        self.assertIn("powerslide", profile)

    def test_typed_system_prompt_includes_long_term_memory(self):
        with patch("memory.memory_manager.load_memory", return_value={"identity": {}}), \
             patch("memory.memory_manager.format_memory_for_prompt", return_value="KNOWN USER FACT"):
            text = local_mode.system_prompt()
        self.assertIn("KNOWN USER FACT", text)

    def test_background_reply_guard_blocks_high_stakes_message(self):
        worker = WhatsAppWorker()
        cfg = {
            "whatsapp_auto_reply": True,
            "whatsapp_auto_reply_all": True,
            "whatsapp_auto_reply_contacts": [],
            "whatsapp_high_stakes_guard": True,
            "whatsapp_max_auto_replies_per_contact_per_hour": 6,
        }
        with patch("core.whatsapp_web.autonomy.load", return_value=cfg):
            ok, reason = worker._allowed_to_reply("Test", "Please send me your password")
        self.assertFalse(ok)
        self.assertIn("high-stakes", reason)


if __name__ == "__main__":
    unittest.main()
