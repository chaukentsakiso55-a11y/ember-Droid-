"""WhatsApp Web control + optional local auto-reply worker for Ember.

The browser runs in a dedicated persistent Playwright profile. The user signs in
once with WhatsApp's normal QR/device flow; Ember never stores WhatsApp account
passwords. Background replies are OFF by default and only run when explicitly
enabled in config/autonomy.json or the Autonomy settings panel.
"""
from __future__ import annotations

import json
import queue
import re
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core import autonomy

BASE_DIR = Path(__file__).resolve().parent.parent

# Background auto-reply deliberately pauses on messages where silently acting as
# the user would be risky. Direct user-issued sends are not affected by this.
_HIGH_STAKES_RE = re.compile(
    r"\b(password|passcode|otp|verification code|bank|payment|money|transfer|"
    r"emergency|police|hospital|lawyer|court|suicide|self[- ]?harm|kill myself|"
    r"nude|explicit)\b",
    re.I,
)


def _profile_dir() -> Path:
    raw = str(autonomy.get("whatsapp_profile_dir", "runtime/whatsapp-profile") or "runtime/whatsapp-profile")
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = BASE_DIR / p
    p.mkdir(parents=True, exist_ok=True)
    return p


def _clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _memory_context() -> str:
    try:
        from memory.memory_manager import load_memory, format_memory_for_prompt
        return format_memory_for_prompt(load_memory())
    except Exception:
        return ""


def _draft_reply(contact: str, history: list[dict[str, str]]) -> str:
    """Generate one short reply using Ember's current provider pool/local fallback."""
    from core.llm_client import call_llm_text
    recent = "\n".join(
        f"{('Them' if row.get('direction') == 'in' else 'User')}: {row.get('text','')}"
        for row in history[-8:]
    )
    system = (
        "You are Ember helping the user reply to a WhatsApp conversation. "
        "Write exactly one short, natural reply that the user could send. "
        "Do not claim facts you were not given. Do not include quotation marks, labels, analysis, or markdown. "
        "If the message needs a major personal, financial, legal, medical, safety, or account-security decision, output exactly: NEEDS_USER.\n\n"
        + _memory_context()
    )
    prompt = f"Contact: {contact}\nRecent conversation:\n{recent}\n\nReply now."
    return _clean_text(call_llm_text(prompt, system=system, timeout=60, max_tokens=180))


@dataclass
class _Command:
    op: str
    args: dict[str, Any]
    event: threading.Event
    box: dict[str, Any]


class WhatsAppWorker:
    def __init__(self) -> None:
        self._queue: queue.Queue[_Command] = queue.Queue()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._ready = threading.Event()
        self._stop = threading.Event()
        self._last_error = ""
        self._signed_in = False
        self._last_seen: dict[str, str] = {}
        self._reply_times: dict[str, deque[float]] = defaultdict(deque)

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._ready.clear()
            self._thread = threading.Thread(target=self._run, name="Ember-WhatsApp", daemon=True)
            self._thread.start()

    def call(self, op: str, timeout: float = 45.0, **args):
        self.start()
        cmd = _Command(op=op, args=args, event=threading.Event(), box={})
        self._queue.put(cmd)
        if not cmd.event.wait(timeout=max(1.0, timeout)):
            return {"ok": False, "error": f"WhatsApp operation '{op}' timed out."}
        return cmd.box.get("result", {"ok": False, "error": "No result returned."})

    def status(self) -> dict:
        return {
            "running": bool(self._thread and self._thread.is_alive()),
            "ready": self._ready.is_set(),
            "signed_in": self._signed_in,
            "last_error": self._last_error,
            "auto_reply": bool(autonomy.get("whatsapp_auto_reply", False)),
        }

    # ---- Playwright helpers -------------------------------------------------
    @staticmethod
    def _search_box(page):
        candidates = [
            'div[role="textbox"][aria-label*="Search"]',
            'div[contenteditable="true"][data-tab="3"]',
            '[data-testid="chat-list-search"]',
        ]
        for sel in candidates:
            loc = page.locator(sel)
            try:
                if loc.count() and loc.first.is_visible():
                    return loc.first
            except Exception:
                pass
        try:
            loc = page.get_by_role("textbox", name=re.compile("search", re.I))
            if loc.count():
                return loc.first
        except Exception:
            pass
        return None

    @staticmethod
    def _composer(page):
        candidates = [
            'footer div[contenteditable="true"][role="textbox"]',
            '[data-testid="conversation-compose-box-input"]',
            'footer div[contenteditable="true"]',
        ]
        for sel in candidates:
            loc = page.locator(sel)
            try:
                if loc.count() and loc.first.is_visible():
                    return loc.first
            except Exception:
                pass
        return None

    def _signed_in_now(self, page) -> bool:
        try:
            return self._search_box(page) is not None
        except Exception:
            return False

    def _ensure_home(self, page) -> None:
        if "web.whatsapp.com" not in (page.url or ""):
            page.goto("https://web.whatsapp.com/", wait_until="domcontentloaded", timeout=45_000)
        self._signed_in = self._signed_in_now(page)

    def _open_chat(self, page, contact: str) -> tuple[bool, str]:
        self._ensure_home(page)
        if not self._signed_in:
            return False, "WhatsApp Web is not signed in. Open it with Ember and scan the QR code once."
        search = self._search_box(page)
        if search is None:
            return False, "Could not find the WhatsApp search box."
        try:
            search.click()
            page.keyboard.press("Control+A")
            search.fill(contact)
            page.wait_for_timeout(700)
            # Exact title is best; text fallback handles contacts whose title is not exposed.
            target = page.locator('span[title="' + contact.replace('"', '\\"') + '"]')
            if not target.count():
                target = page.get_by_text(contact, exact=True)
            if not target.count():
                page.keyboard.press("Escape")
                return False, f"Could not find WhatsApp contact '{contact}'."
            target.first.click()
            page.wait_for_timeout(500)
            return True, ""
        except Exception as e:
            return False, f"Could not open WhatsApp chat '{contact}': {e}"

    def _history(self, page, limit: int = 8) -> list[dict[str, str]]:
        rows: list[dict[str, str]] = []
        try:
            nodes = page.locator("div.message-in, div.message-out")
            count = nodes.count()
            for i in range(max(0, count - max(1, limit)), count):
                node = nodes.nth(i)
                cls = node.get_attribute("class") or ""
                direction = "in" if "message-in" in cls else "out"
                txt = ""
                for sel in ("span.selectable-text", "div.copyable-text", "span[dir=auto]"):
                    part = node.locator(sel)
                    if part.count():
                        try:
                            txt = _clean_text(part.last.inner_text())
                        except Exception:
                            txt = ""
                        if txt:
                            break
                if txt:
                    rows.append({"direction": direction, "text": txt})
        except Exception:
            pass
        return rows[-limit:]

    def _last_incoming(self, page) -> tuple[str, str]:
        try:
            nodes = page.locator("div.message-in")
            if not nodes.count():
                return "", ""
            node = nodes.last
            msg_id = node.get_attribute("data-id") or ""
            if not msg_id:
                try:
                    msg_id = node.locator("[data-id]").last.get_attribute("data-id") or ""
                except Exception:
                    pass
            text = ""
            for sel in ("span.selectable-text", "div.copyable-text", "span[dir=auto]"):
                part = node.locator(sel)
                if part.count():
                    try:
                        text = _clean_text(part.last.inner_text())
                    except Exception:
                        text = ""
                    if text:
                        break
            marker = msg_id or text
            return marker, text
        except Exception:
            return "", ""

    def _send_current(self, page, text: str) -> tuple[bool, str]:
        composer = self._composer(page)
        if composer is None:
            return False, "Could not find the WhatsApp message box."
        try:
            composer.click()
            composer.fill(text)
            page.keyboard.press("Enter")
            page.wait_for_timeout(350)
            return True, "sent"
        except Exception as e:
            return False, f"Could not type/send the WhatsApp message: {e}"

    def _send(self, page, contact: str, text: str) -> dict:
        ok, err = self._open_chat(page, contact)
        if not ok:
            return {"ok": False, "error": err}
        ok, detail = self._send_current(page, text)
        return {"ok": ok, "contact": contact, "detail": detail if ok else "", "error": "" if ok else detail}

    def _read_last(self, page, contact: str) -> dict:
        ok, err = self._open_chat(page, contact)
        if not ok:
            return {"ok": False, "error": err}
        marker, text = self._last_incoming(page)
        return {"ok": True, "contact": contact, "message": text, "marker": marker, "history": self._history(page)}

    def _unread_contacts(self, page, limit: int = 12) -> list[str]:
        self._ensure_home(page)
        found: list[str] = []
        # WhatsApp's DOM changes often. These two patterns cover current and older layouts.
        for row_sel in ('div[role="listitem"]', 'div[role="row"]'):
            try:
                rows = page.locator(row_sel)
                for i in range(min(rows.count(), 80)):
                    row = rows.nth(i)
                    unread = row.locator('span[aria-label*="unread" i], [data-testid*="unread"]')
                    if not unread.count():
                        continue
                    names = row.locator("span[title]")
                    if names.count():
                        name = _clean_text(names.first.get_attribute("title") or "")
                        if name and name not in found:
                            found.append(name)
                            if len(found) >= limit:
                                return found
            except Exception:
                continue
        return found

    def _allowed_to_reply(self, contact: str, message: str) -> tuple[bool, str]:
        cfg = autonomy.load()
        if not cfg.get("whatsapp_auto_reply"):
            return False, "disabled"
        allowed = [x.casefold() for x in cfg.get("whatsapp_auto_reply_contacts", [])]
        if not cfg.get("whatsapp_auto_reply_all") and contact.casefold() not in allowed:
            return False, "contact not allowlisted"
        if cfg.get("whatsapp_high_stakes_guard", True) and _HIGH_STAKES_RE.search(message or ""):
            return False, "high-stakes message requires the user"
        now = time.time()
        dq = self._reply_times[contact.casefold()]
        while dq and dq[0] < now - 3600:
            dq.popleft()
        if len(dq) >= int(cfg.get("whatsapp_max_auto_replies_per_contact_per_hour", 6)):
            return False, "hourly auto-reply limit reached"
        return True, ""

    def _auto_contacts(self, page) -> list[str]:
        cfg = autonomy.load()
        contacts = list(cfg.get("whatsapp_auto_reply_contacts", []))
        if cfg.get("whatsapp_auto_reply_all"):
            for name in self._unread_contacts(page):
                if name not in contacts:
                    contacts.append(name)
        return contacts[:20]

    def _poll_auto(self, page) -> None:
        if not autonomy.get("whatsapp_auto_reply", False):
            return
        for contact in self._auto_contacts(page):
            try:
                ok, _ = self._open_chat(page, contact)
                if not ok:
                    continue
                marker, incoming = self._last_incoming(page)
                if not marker or not incoming:
                    continue
                key = contact.casefold()
                if self._last_seen.get(key) == marker:
                    continue
                self._last_seen[key] = marker
                allowed, _reason = self._allowed_to_reply(contact, incoming)
                if not allowed:
                    continue
                history = self._history(page, limit=8)
                reply = _draft_reply(contact, history)
                if not reply or reply.upper() == "NEEDS_USER":
                    continue
                ok, _ = self._send_current(page, reply)
                if ok:
                    self._reply_times[key].append(time.time())
            except Exception as e:
                self._last_error = f"Auto-reply poll: {e}"

    def _run(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except Exception as e:
            self._last_error = f"Playwright unavailable: {e}"
            self._ready.set()
            # Drain commands with a useful failure instead of hanging callers.
            while not self._stop.is_set():
                try: cmd = self._queue.get(timeout=0.5)
                except queue.Empty: continue
                cmd.box["result"] = {"ok": False, "error": self._last_error}
                cmd.event.set()
            return

        try:
            with sync_playwright() as p:
                context = p.chromium.launch_persistent_context(
                    str(_profile_dir()),
                    headless=bool(autonomy.get("whatsapp_browser_headless", False)),
                    viewport={"width": 1280, "height": 900},
                    args=["--disable-notifications"],
                )
                page = context.pages[0] if context.pages else context.new_page()
                try:
                    self._ensure_home(page)
                except Exception as e:
                    self._last_error = str(e)
                self._ready.set()

                next_poll = time.monotonic() + 2.0
                while not self._stop.is_set():
                    timeout = max(0.1, min(1.0, next_poll - time.monotonic()))
                    try:
                        cmd = self._queue.get(timeout=timeout)
                    except queue.Empty:
                        cmd = None
                    if cmd is not None:
                        try:
                            if cmd.op == "login":
                                self._ensure_home(page)
                                try: page.bring_to_front()
                                except Exception: pass
                                result = {"ok": True, "signed_in": self._signed_in, "message": "WhatsApp Web opened. Scan the QR code if requested."}
                            elif cmd.op == "send":
                                result = self._send(page, str(cmd.args.get("contact") or ""), str(cmd.args.get("text") or ""))
                            elif cmd.op == "read_last":
                                result = self._read_last(page, str(cmd.args.get("contact") or ""))
                            elif cmd.op == "unread":
                                result = {"ok": True, "contacts": self._unread_contacts(page)}
                            elif cmd.op == "status":
                                self._ensure_home(page)
                                result = {"ok": True, "signed_in": self._signed_in, "url": page.url}
                            elif cmd.op == "stop":
                                result = {"ok": True}; self._stop.set()
                            else:
                                result = {"ok": False, "error": f"Unknown WhatsApp operation: {cmd.op}"}
                        except Exception as e:
                            self._last_error = str(e)
                            result = {"ok": False, "error": str(e)}
                        cmd.box["result"] = result
                        cmd.event.set()

                    now = time.monotonic()
                    if now >= next_poll:
                        try:
                            self._poll_auto(page)
                        except Exception as e:
                            self._last_error = str(e)
                        next_poll = now + int(autonomy.get("whatsapp_poll_seconds", 6))
                context.close()
        except Exception as e:
            self._last_error = f"WhatsApp browser failed: {e}"
            self._ready.set()
            # Return errors to any queued callers.
            while True:
                try: cmd = self._queue.get_nowait()
                except queue.Empty: break
                cmd.box["result"] = {"ok": False, "error": self._last_error}
                cmd.event.set()


_WORKER = WhatsAppWorker()


def start_if_enabled() -> None:
    if autonomy.get("whatsapp_auto_reply", False):
        _WORKER.start()


def open_login() -> dict:
    return _WORKER.call("login", timeout=60)


def send_message(contact: str, text: str) -> dict:
    if not autonomy.get("messaging_enabled", True):
        return {"ok": False, "error": "Messaging is disabled in Ember autonomy settings."}
    if not contact.strip() or not text.strip():
        return {"ok": False, "error": "Contact and message are required."}
    return _WORKER.call("send", timeout=60, contact=contact.strip(), text=text.strip())


def read_last(contact: str) -> dict:
    return _WORKER.call("read_last", timeout=45, contact=contact.strip())


def unread_contacts() -> dict:
    return _WORKER.call("unread", timeout=30)


def status() -> dict:
    base = _WORKER.status()
    if base["running"]:
        live = _WORKER.call("status", timeout=15)
        if isinstance(live, dict): base.update(live)
    return base
