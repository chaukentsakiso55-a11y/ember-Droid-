"""Local autonomy and control settings for Ember.

Safety defaults are intentionally conservative: direct user-issued desktop and
messaging commands are allowed, but background/unsupervised WhatsApp replies are
off until the user explicitly enables them. All settings remain local.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
PATH = BASE_DIR / "config" / "autonomy.json"
_LOCK = threading.RLock()

DEFAULTS = {
    "desktop_control_enabled": True,
    "game_control_enabled": True,
    "messaging_enabled": True,
    "whatsapp_auto_reply": False,
    "whatsapp_auto_reply_all": False,
    "whatsapp_auto_reply_contacts": [],
    "whatsapp_poll_seconds": 6,
    "whatsapp_max_auto_replies_per_contact_per_hour": 6,
    "whatsapp_browser_headless": False,
    "whatsapp_profile_dir": "runtime/whatsapp-profile",
    "whatsapp_high_stakes_guard": True,
    "emergency_stop_hotkey": "ctrl+alt+esc",
    "max_parallel_non_desktop_tasks": 4,
}


def _normalise(data: dict | None) -> dict:
    out = dict(DEFAULTS)
    if isinstance(data, dict):
        out.update(data)
    contacts = out.get("whatsapp_auto_reply_contacts", [])
    if isinstance(contacts, str):
        contacts = [x.strip() for x in contacts.split(",") if x.strip()]
    if not isinstance(contacts, list):
        contacts = []
    out["whatsapp_auto_reply_contacts"] = list(dict.fromkeys(str(x).strip() for x in contacts if str(x).strip()))
    try:
        out["whatsapp_poll_seconds"] = max(3, min(60, int(out.get("whatsapp_poll_seconds", 6))))
    except Exception:
        out["whatsapp_poll_seconds"] = 6
    try:
        out["whatsapp_max_auto_replies_per_contact_per_hour"] = max(
            1, min(60, int(out.get("whatsapp_max_auto_replies_per_contact_per_hour", 6)))
        )
    except Exception:
        out["whatsapp_max_auto_replies_per_contact_per_hour"] = 6
    try:
        out["max_parallel_non_desktop_tasks"] = max(1, min(8, int(out.get("max_parallel_non_desktop_tasks", 4))))
    except Exception:
        out["max_parallel_non_desktop_tasks"] = 4
    for key in (
        "desktop_control_enabled", "game_control_enabled", "messaging_enabled",
        "whatsapp_auto_reply", "whatsapp_auto_reply_all", "whatsapp_browser_headless",
        "whatsapp_high_stakes_guard",
    ):
        out[key] = bool(out.get(key, DEFAULTS[key]))
    return out


def load() -> dict:
    with _LOCK:
        try:
            raw = json.loads(PATH.read_text(encoding="utf-8")) if PATH.exists() else {}
        except Exception:
            raw = {}
        # The generic Plugin Settings UI stores values in api_keys.json under
        # plugin_config.autonomy. Merge those over the dedicated defaults so a
        # toggle changed in the UI takes effect immediately without restart.
        try:
            api = json.loads((BASE_DIR / "config" / "api_keys.json").read_text(encoding="utf-8"))
            plugin_cfg = ((api.get("plugin_config") or {}).get("autonomy") or {}) if isinstance(api, dict) else {}
            if isinstance(plugin_cfg, dict):
                raw = {**(raw if isinstance(raw, dict) else {}), **plugin_cfg}
        except Exception:
            pass
        return _normalise(raw)


def save(values: dict) -> dict:
    with _LOCK:
        current = load()
        if isinstance(values, dict):
            current.update(values)
        current = _normalise(current)
        PATH.parent.mkdir(parents=True, exist_ok=True)
        PATH.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")
        # Keep the generic Plugin Settings panel in sync with voice/tool changes.
        try:
            from memory.config_manager import save_plugin_config
            ui_values = dict(current)
            ui_values["whatsapp_auto_reply_contacts"] = ", ".join(current.get("whatsapp_auto_reply_contacts", []))
            save_plugin_config("autonomy", ui_values)
        except Exception:
            pass
        return current


def get(key: str, default=None):
    return load().get(key, default)


def set_value(key: str, value):
    return save({key: value}).get(key)


def status_text() -> str:
    cfg = load()
    contacts = cfg.get("whatsapp_auto_reply_contacts", [])
    return (
        "Autonomy settings\n"
        f"Desktop control: {'ON' if cfg['desktop_control_enabled'] else 'OFF'}\n"
        f"Game control: {'ON' if cfg['game_control_enabled'] else 'OFF'}\n"
        f"Messaging: {'ON' if cfg['messaging_enabled'] else 'OFF'}\n"
        f"WhatsApp auto-reply: {'ON' if cfg['whatsapp_auto_reply'] else 'OFF'}\n"
        f"Auto-reply all chats: {'ON' if cfg['whatsapp_auto_reply_all'] else 'OFF'}\n"
        f"Auto-reply contacts: {', '.join(contacts) if contacts else 'none'}\n"
        f"Emergency stop: {cfg['emergency_stop_hotkey']}"
    )
