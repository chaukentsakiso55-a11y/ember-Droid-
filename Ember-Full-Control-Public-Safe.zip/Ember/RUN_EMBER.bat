@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title EMBER - One Click Launcher

set "VENV_DIR=.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "SETUP_MARKER=%VENV_DIR%\.ember_setup_complete"
set "FORCE_SETUP=0"

if /I "%~1"=="repair" set "FORCE_SETUP=1"
if /I "%~1"=="setup" set "FORCE_SETUP=1"

cls
echo ============================================================
echo                     EMBER LAUNCHER
echo ============================================================
echo.

rem ------------------------------------------------------------
rem 1. Reuse Ember's virtual environment if it already exists.
rem ------------------------------------------------------------
if exist "%VENV_PY%" goto :VENV_READY

echo [1/4] Looking for Python 3.11 - 3.13...
call :FIND_PYTHON
if errorlevel 1 goto :NO_PYTHON

echo [2/4] Creating Ember virtual environment...
%BASE_PY% %BASE_PY_ARG% -m venv "%VENV_DIR%"
if errorlevel 1 goto :VENV_FAILED

:VENV_READY
if not exist "%VENV_PY%" goto :VENV_FAILED

echo [3/4] Preparing Ember...

rem ------------------------------------------------------------
rem 2. Run full setup the first time, or when "repair" is passed.
rem    setup.py installs requirements and Playwright browsers.
rem ------------------------------------------------------------
if "%FORCE_SETUP%"=="1" goto :DO_SETUP
if not exist "%SETUP_MARKER%" goto :DO_SETUP

echo       Existing setup detected - skipping dependency reinstall.
goto :START_EMBER

:DO_SETUP
echo       Updating pip, setuptools and wheel...
"%VENV_PY%" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :SETUP_FAILED

echo.
echo       Running Ember OS-aware setup...
"%VENV_PY%" setup.py
if errorlevel 1 goto :SETUP_FAILED

> "%SETUP_MARKER%" echo Setup completed successfully.

:START_EMBER
echo.
echo [4/4] Starting Ember...
echo ============================================================
echo.
"%VENV_PY%" main.py
set "EMBER_EXIT=%ERRORLEVEL%"

if "%EMBER_EXIT%"=="0" goto :DONE

echo.
echo ============================================================
echo Ember stopped with exit code %EMBER_EXIT%.
echo.
echo If this was caused by a missing or damaged dependency, run:
echo     RUN_EMBER.bat repair
echo ============================================================
pause
exit /b %EMBER_EXIT%

:DONE
endlocal
exit /b 0

:FIND_PYTHON
rem Prefer versions Ember is tested on. The Windows Python Launcher
rem lets several Python versions coexist without changing PATH.
for %%V in (3.13 3.12 3.11) do (
    py -%%V -c "import sys; raise SystemExit(sys.version_info[:2] not in ((3,11),(3,12),(3,13)))" >nul 2>&1
    if not errorlevel 1 (
        set "BASE_PY=py"
        set "BASE_PY_ARG=-%%V"
        exit /b 0
    )
)

rem Fallback for machines where Python is on PATH but the py launcher is not.
python -c "import sys; raise SystemExit(sys.version_info[:2] not in ((3,11),(3,12),(3,13)))" >nul 2>&1
if not errorlevel 1 (
    set "BASE_PY=python"
    set "BASE_PY_ARG="
    exit /b 0
)

exit /b 1

:NO_PYTHON
echo.
echo ERROR: Ember needs Python 3.11, 3.12, or 3.13.
echo Install a supported 64-bit Python for Windows, then run this file again.
echo.
echo If you already have Python 3.11-3.13 installed, make sure either
echo the "py" launcher or "python" command is available in PATH.
echo.
pause
exit /b 1

:VENV_FAILED
echo.
echo ERROR: Ember could not create or open its virtual environment.
echo Delete the .venv folder and run RUN_EMBER.bat again.
echo.
pause
exit /b 1

:SETUP_FAILED
echo.
echo ============================================================
echo ERROR: Ember setup did not complete successfully.
echo Check the message above for the package or network error.
echo.
echo You can retry the complete setup with:
echo     RUN_EMBER.bat repair
echo ============================================================
pause
exit /b 1
