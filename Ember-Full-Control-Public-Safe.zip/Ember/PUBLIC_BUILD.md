# Ember Public Build

This build contains no API keys, linked WhatsApp session, or personal long-term memory.

Add provider keys locally after download using Ember's provider settings or environment variables.
Do not commit `config/provider_secrets.json`, `config/api_keys.json`, WhatsApp session data, or personal memory.
