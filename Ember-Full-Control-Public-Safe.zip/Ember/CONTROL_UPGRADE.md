# Ember Control Upgrade

This build adds a more reliable computer-control layer without changing Ember's core multi-provider architecture.

## PC game control

`game_control` is a dedicated action for active games. On Windows it prefers **PyDirectInput**, which is more likely than ordinary GUI automation to be accepted by DirectX games. It supports held keys, simultaneous steering + acceleration, short macros, control profiles, window focus, and emergency key release.

Included profiles:

- `generic_racing`
- `beach_buggy_racing`
- `beach_buggy_racing_2`

Ember's prompt now tells the model to use `game_control` for gameplay rather than sending one ordinary keypress and assuming it worked. If a move depends on the screen, Ember can combine this with its existing `screen_process` vision action.

## WhatsApp Web

`whatsapp_control` runs WhatsApp Web in a persistent Playwright browser profile under `runtime/whatsapp-profile`. Sign in once using WhatsApp's normal QR flow. Ember can then:

- send a message to a named contact;
- read the latest incoming text from a named contact;
- check detected unread chats;
- maintain an allowlist for background replies;
- enable or disable automatic replies.

Background replies are **OFF by default**. The settings are available under **Plugin Settings → Ember Autonomy & Messaging**. A high-stakes guard and per-contact rate limit remain active for background replies.

The older generic `send_message` action now tries the verified WhatsApp Web path first and falls back to the installed WhatsApp desktop/PWA UI when needed.

## Multitasking

If an LLM emits several independent tool calls in one turn, Ember can now execute up to four non-desktop tasks concurrently. Tasks that share the keyboard/mouse, messaging UI, memory writes, or visible screen stay serialized to prevent them fighting over focus.

## Personal memory

Typed local and multi-provider chat now use the same long-term memory block as Ember Live. The bundled local profile contains a small set of user-approved, non-sensitive preferences and projects, including the corrected favorite food: **chicken nuggets**. Ember can continue learning through its existing `save_memory` tool and Memory panel.

## Controls and safety switches

`config/autonomy.json` stores defaults. The same values can be changed from the Plugin Settings panel. Desktop control, game control, and messaging can each be disabled independently, and WhatsApp auto-reply can be switched off at any time.
